import pygame # spacebar_code == 32, esc_code == 27, enter_code == 13
import random
import time
import sys # eye_open - 1 / eye_closed - 2 / walk - 3 / right - 4 / left - 5 / rest - 6
import pyautogui

# pygame 초기화
pygame.init()

# 창 크기 설정
screen_width = 800
screen_height = 600
white = (255, 255, 255)

# 자극 이미지
leftImg = pygame.image.load("C:/Users/OST/Desktop/pg1/Stimulus_generator/Left.jpg")
rightImg = pygame.image.load("C:/Users/OST/Desktop/pg1/Stimulus_generator/Right.jpg")
walkImg = pygame.image.load("C:/Users/OST/Desktop/pg1/Stimulus_generator/walk.jpg")
cEyeImg = pygame.image.load("C:/Users/OST/Desktop/pg1/Stimulus_generator/closed_eye.png")
oEyeImg = pygame.image.load("C:/Users/OST/Desktop/pg1/Stimulus_generator/open_eye.png")
endImg = pygame.image.load("C:/Users/OST/Desktop/pg1/Stimulus_generator/end.png")
restImg = pygame.image.load("C:/Users/OST/Desktop/pg1/Stimulus_generator/rest.png")

clock = pygame.time.Clock()

# 메인 화면
def mainmenu():
    # 화면 크기
    start_screen = pygame.display.set_mode((800, 600))

    pygame.font.init()
    start_font = pygame.font.SysFont('Sans', 40, True, True)
    start_message = 'Press the Space Bar to Start.'
    start_message_object = start_font.render(start_message, True, (0,0,0))
    start_message_rect = start_message_object.get_rect()
    start_message_rect.center = (250, 250)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                return
        start_screen.fill(white)
        start_screen.blit(start_message_object, start_message_rect)
        pygame.display.update()

# eye_open 화면
def eye_open_Screen():
    start_time = time.time()
    pyautogui.platformModule._keyDown('1')
    #pyautogui.platformModule._keyUp('1')
    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"키보드 입력에 걸린 시간: {elapsed_time} 초")
    screen = pygame.display.set_mode((800, 600))
    screen.fill(white)
    Stimul = screen.blit(oEyeImg, (4, 5))
    pygame.display.update()

# eye_closed 화면
def eye_closed_Screen():
    start_time = time.time()
    pyautogui.platformModule._keyDown('2')
    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"키보드 입력에 걸린 시간: {elapsed_time} 초")
    screen = pygame.display.set_mode((800, 600))
    screen.fill(white)
    Stimul = screen.blit(cEyeImg, (4, 5))
    pygame.display.update()

# walk 화면
def walk_Screen():
    start_time = time.time()
    pyautogui.platformModule._keyDown('3')
    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"키보드 입력에 걸린 시간: {elapsed_time} 초")
    screen = pygame.display.set_mode((800, 600))
    screen.fill(white)
    Stimul = screen.blit(walkImg, (4, 5))
    pygame.display.update()

# right 화면
def right_Screen():
    start_time = time.time()
    pyautogui.platformModule._keyDown('4')
    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"키보드 입력에 걸린 시간: {elapsed_time} 초")
    screen = pygame.display.set_mode((800, 600))
    screen.fill(white)
    Stimul = screen.blit(rightImg, (4, 5))
    pygame.display.update()

# left 화면
def left_Screen():
    start_time = time.time()
    pyautogui.platformModule._keyDown('5')
    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"키보드 입력에 걸린 시간: {elapsed_time} 초")
    screen = pygame.display.set_mode((800, 600))
    screen.fill(white)
    Stimul = screen.blit(leftImg, (4, 5))
    pygame.display.update()

# end 화면
def end_Screen():
    screen = pygame.display.set_mode((800, 600))
    screen.fill(white)
    Stimul = screen.blit(endImg, (4, 5))
    pygame.display.update()

# rest 화면
def rest_Screen():
    start_time = time.time()
    pyautogui.platformModule._keyDown('6')
    # pyautogui.platformModule._keyUp('6')
    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"키보드 입력에 걸린 시간: {elapsed_time} 초")
    screen = pygame.display.set_mode((800, 600))
    screen.fill(white)
    Stimul = screen.blit(restImg, (4, 5))
    pygame.display.update()


stimul = [1, 2, 3, 4, 5]
# 각각 몇번씩 진행할지 정하기
test_stimul = stimul * 5
random.shuffle(test_stimul)
print(test_stimul)
mainmenu()
for i in test_stimul:
    if i == 1:
        right_Screen()
        print("right")
        time.sleep(2)
        rest_Screen()
        print("rest")
        time.sleep(2)
    elif i == 2:
        eye_closed_Screen()
        print("eye_closed")
        time.sleep(2)
        rest_Screen()
        print("rest")
        time.sleep(2)
    elif i == 3:
        eye_open_Screen()
        print("eye_open")
        time.sleep(2)
        rest_Screen()
        print("rest")
        time.sleep(2)
    elif i == 4:
        left_Screen()
        print("left")
        time.sleep(2)
        rest_Screen()
        print("rest")
        time.sleep(2)
    elif i == 5:
        walk_Screen()
        print("walk")
        time.sleep(2)
        rest_Screen()
        print("rest")
        time.sleep(2)
end_Screen()
print("end")
time.sleep(2)
pygame.quit()